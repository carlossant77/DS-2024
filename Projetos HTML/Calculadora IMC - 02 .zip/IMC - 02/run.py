from flask import Flask, render_template, request, redirect

app = Flask(__name__)

@app.route("/")
def index():

    dados = []
    caminho_arquivo = 'models/dados_imc_arquivo.txt'

    with open(caminho_arquivo, 'r') as arquivo:
        for dado in arquivo:
            item = dado.strip().split(';')
            dados.append({
                'nome': item[0],
                'peso': item[1],
                'altura': item[2],  
                'imc': round(float(item[3]), 2),
                'status': item[4]
            })

    ultimo_dado = dados[-1] if dados else None

    return render_template("index.html", ultimo_dado=ultimo_dado)

@app.route("/dados_imc", methods=['POST'])
def dados_imc():
    nome = request.form["nome"]
    peso = request.form["peso"]
    altura = request.form["altura"]

    caminho_arquivo = 'models/dados_imc_arquivo.txt'

    n1 = request.form["altura"]
    n2 = request.form["peso"]

    imc = float(n2) / (float(n1)*float(n1))

    if imc < 18.5:
        status = "Magreza"
    elif imc < 25.0:
        status = "Peso Adequado"
    elif imc < 30.0:
        status = "Sobrepeso" 
    elif imc < 40.0:
        status = "Obesidade"
    else:
        status = "Obesidade Grave"

    with open(caminho_arquivo, 'a') as arquivo:
        arquivo.write(f"{nome};{peso};{altura};{imc};{status}\n")

    return redirect("/")

@app.route("/resultados")
def mostrar_imc():
    dados = []
    caminho_arquivo = 'models/dados_imc_arquivo.txt'

    with open(caminho_arquivo, 'r') as arquivo:
        for dado in arquivo:
            item = dado.strip().split(';')
            dados.append({
                'nome': item[0],
                'peso': item[1],
                'altura': item[2],  
                'imc': (round(float(item[3]),2)),
                'status': item[4]
            })

    ultimo_dado = dados[-1] if dados else None

    return render_template("pagina_resultados.html", inf=dados, ultimo_dado=ultimo_dado)


app.run(host='127.0.0.1', port=80, debug=True)